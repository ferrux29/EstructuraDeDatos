#include "StdAfx.h"
#include "Vectr.h"
#define Nmax 100


Vectr::Vectr(void)
{vec[Nmax]=0;
 tamano=0;
}
int Vectr::get_tamano()
{return tamano;}
void Vectr::set_tamano(int t)
{tamano=t;}
int Vectr::get_vector(int posicion)
{return vec[posicion];}
void Vectr::set_vector(int posicion, int elemento)
{vec[posicion]=elemento;}