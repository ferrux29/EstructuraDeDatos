#pragma once
#define Nmax 100
class Vectr
{
private:
	 int vec[Nmax];
	 int tamano;
public:
	Vectr(void);
	int get_tamano();
	void set_tamano(int t);
	int get_vector(int posicion);
	void set_vector(int posicion, int elemento);
};

