#pragma once
#include <iostream>
#include <string>
#include "Vectr.h"
#include <msclr\marshal_cppstd.h>
#include <iomanip>

namespace vector {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;


	Vectr arreglo_reg_val;
	float pos=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::TextBox^  txtTam;
	protected: 

	private: System::Windows::Forms::DataGridView^  grilla_valores;

	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::Button^  btbOrdenar;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtVal;
	private: System::Windows::Forms::Button^  btbIngresar;
	private: System::Windows::Forms::Button^  btbDefinir;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtTam = (gcnew System::Windows::Forms::TextBox());
			this->grilla_valores = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btbOrdenar = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtVal = (gcnew System::Windows::Forms::TextBox());
			this->btbIngresar = (gcnew System::Windows::Forms::Button());
			this->btbDefinir = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_valores))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(15, 67);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(46, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Tama�o";
			// 
			// txtTam
			// 
			this->txtTam->Location = System::Drawing::Point(85, 64);
			this->txtTam->Name = L"txtTam";
			this->txtTam->Size = System::Drawing::Size(68, 20);
			this->txtTam->TabIndex = 1;
			// 
			// grilla_valores
			// 
			this->grilla_valores->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla_valores->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grilla_valores->Location = System::Drawing::Point(18, 177);
			this->grilla_valores->Name = L"grilla_valores";
			this->grilla_valores->Size = System::Drawing::Size(240, 150);
			this->grilla_valores->TabIndex = 2;
			this->grilla_valores->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Form1::grilla_nota_CellContentClick);
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Valores";
			this->Column1->Name = L"Column1";
			// 
			// btbOrdenar
			// 
			this->btbOrdenar->Location = System::Drawing::Point(273, 177);
			this->btbOrdenar->Name = L"btbOrdenar";
			this->btbOrdenar->Size = System::Drawing::Size(91, 34);
			this->btbOrdenar->TabIndex = 3;
			this->btbOrdenar->Text = L"Ordenar";
			this->btbOrdenar->UseVisualStyleBackColor = true;
			this->btbOrdenar->Click += gcnew System::EventHandler(this, &Form1::btbOrdenar_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(19, 113);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(42, 13);
			this->label2->TabIndex = 4;
			this->label2->Text = L"Valores";
			// 
			// txtVal
			// 
			this->txtVal->Location = System::Drawing::Point(85, 111);
			this->txtVal->Name = L"txtVal";
			this->txtVal->Size = System::Drawing::Size(68, 20);
			this->txtVal->TabIndex = 5;
			// 
			// btbIngresar
			// 
			this->btbIngresar->Location = System::Drawing::Point(177, 103);
			this->btbIngresar->Name = L"btbIngresar";
			this->btbIngresar->Size = System::Drawing::Size(81, 34);
			this->btbIngresar->TabIndex = 6;
			this->btbIngresar->Text = L"Ingresar";
			this->btbIngresar->UseVisualStyleBackColor = true;
			this->btbIngresar->Click += gcnew System::EventHandler(this, &Form1::btbIngresar_Click);
			// 
			// btbDefinir
			// 
			this->btbDefinir->Location = System::Drawing::Point(177, 58);
			this->btbDefinir->Name = L"btbDefinir";
			this->btbDefinir->Size = System::Drawing::Size(80, 31);
			this->btbDefinir->TabIndex = 7;
			this->btbDefinir->Text = L"Definir";
			this->btbDefinir->UseVisualStyleBackColor = true;
			this->btbDefinir->Click += gcnew System::EventHandler(this, &Form1::btbDefinir_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(376, 375);
			this->Controls->Add(this->btbDefinir);
			this->Controls->Add(this->btbIngresar);
			this->Controls->Add(this->txtVal);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->btbOrdenar);
			this->Controls->Add(this->grilla_valores);
			this->Controls->Add(this->txtTam);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_valores))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 }
	private: System::Void grilla_nota_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
			 }
	private: System::Void btbDefinir_Click(System::Object^  sender, System::EventArgs^  e) {
			 int tam;
			 tam=System::Convert::ToInt32(txtTam->Text);
			 arreglo_reg_val.Set_tama�o(tam);
			 grilla_valores->RowCount=arreglo_reg_val.Get_tama�o();
			 pos=0;}
private: System::Void btbIngresar_Click(System::Object^  sender, System::EventArgs^  e) {
		 float elemento;
			 elemento=System::Convert::ToDouble(txtVal->Text);
			 if (arreglo_reg_val.Insertar(elemento,pos)) {
				pos++;
				grilla_valores->ColumnCount=1;
				grilla_valores->RowCount=arreglo_reg_val.Get_tama�o();
				float i=0, val;
				for (i=0;i<arreglo_reg_val.Get_tama�o();i++)
				{
				val=arreglo_reg_val.Get_vector(i);
				grilla_valores->Rows[i]->Cells[0]->Value=System::Convert::ToDouble(val);
				}
			 }
		 }
private: System::Void btbOrdenar_Click(System::Object^  sender, System::EventArgs^  e) {
 arreglo_reg_val.ordenarVector();
 for(int i=0;i<arreglo_reg_val.Get_tama�o();i++){grilla_valores->Rows[i]->Cells[0]->Value=arreglo_reg_val.Get_vector(i);}
		 }
};
}

