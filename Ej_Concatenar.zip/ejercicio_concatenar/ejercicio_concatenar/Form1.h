#pragma once
#include <iostream>
#include "Arreglo.h"
#include <string>


namespace ejercicio_concatenar {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;

	Arreglo vec1;
	Arreglo vec2;
	Arreglo vec3;
	int pos=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  grilla3;
	protected: 
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column3;
	private: System::Windows::Forms::Button^  btbConcatenar;

	private: System::Windows::Forms::DataGridView^  grilla2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::DataGridView^  grilla1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::Button^  btbVal2;

	private: System::Windows::Forms::Button^  btbVal1;

	private: System::Windows::Forms::TextBox^  txtVal2;
	private: System::Windows::Forms::TextBox^  txtVal1;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Button^  btbTam2;

	private: System::Windows::Forms::TextBox^  txtTam2;

	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Button^  btbTam1;

	private: System::Windows::Forms::TextBox^  txtTam1;

	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->grilla3 = (gcnew System::Windows::Forms::DataGridView());
			this->Column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btbConcatenar = (gcnew System::Windows::Forms::Button());
			this->grilla2 = (gcnew System::Windows::Forms::DataGridView());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->grilla1 = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btbVal2 = (gcnew System::Windows::Forms::Button());
			this->btbVal1 = (gcnew System::Windows::Forms::Button());
			this->txtVal2 = (gcnew System::Windows::Forms::TextBox());
			this->txtVal1 = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->btbTam2 = (gcnew System::Windows::Forms::Button());
			this->txtTam2 = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->btbTam1 = (gcnew System::Windows::Forms::Button());
			this->txtTam1 = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla1))->BeginInit();
			this->SuspendLayout();
			// 
			// grilla3
			// 
			this->grilla3->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla3->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column3});
			this->grilla3->Location = System::Drawing::Point(503, 284);
			this->grilla3->Name = L"grilla3";
			this->grilla3->Size = System::Drawing::Size(140, 159);
			this->grilla3->TabIndex = 35;
			// 
			// Column3
			// 
			this->Column3->HeaderText = L"Column3";
			this->Column3->Name = L"Column3";
			// 
			// btbConcatenar
			// 
			this->btbConcatenar->Location = System::Drawing::Point(503, 226);
			this->btbConcatenar->Name = L"btbConcatenar";
			this->btbConcatenar->Size = System::Drawing::Size(75, 23);
			this->btbConcatenar->TabIndex = 34;
			this->btbConcatenar->Text = L"Concatear";
			this->btbConcatenar->UseVisualStyleBackColor = true;
			this->btbConcatenar->Click += gcnew System::EventHandler(this, &Form1::btbConcatenar_Click);
			// 
			// grilla2
			// 
			this->grilla2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column2});
			this->grilla2->Location = System::Drawing::Point(279, 284);
			this->grilla2->Name = L"grilla2";
			this->grilla2->Size = System::Drawing::Size(139, 159);
			this->grilla2->TabIndex = 33;
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Column2";
			this->Column2->Name = L"Column2";
			// 
			// grilla1
			// 
			this->grilla1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grilla1->Location = System::Drawing::Point(34, 284);
			this->grilla1->Name = L"grilla1";
			this->grilla1->Size = System::Drawing::Size(140, 159);
			this->grilla1->TabIndex = 32;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Column1";
			this->Column1->Name = L"Column1";
			// 
			// btbVal2
			// 
			this->btbVal2->Location = System::Drawing::Point(279, 226);
			this->btbVal2->Name = L"btbVal2";
			this->btbVal2->Size = System::Drawing::Size(75, 23);
			this->btbVal2->TabIndex = 31;
			this->btbVal2->Text = L"Ingresar";
			this->btbVal2->UseVisualStyleBackColor = true;
			this->btbVal2->Click += gcnew System::EventHandler(this, &Form1::btbVal2_Click);
			// 
			// btbVal1
			// 
			this->btbVal1->Location = System::Drawing::Point(34, 226);
			this->btbVal1->Name = L"btbVal1";
			this->btbVal1->Size = System::Drawing::Size(75, 23);
			this->btbVal1->TabIndex = 30;
			this->btbVal1->Text = L"Ingresar";
			this->btbVal1->UseVisualStyleBackColor = true;
			this->btbVal1->Click += gcnew System::EventHandler(this, &Form1::btbVal1_Click);
			// 
			// txtVal2
			// 
			this->txtVal2->Location = System::Drawing::Point(328, 173);
			this->txtVal2->Name = L"txtVal2";
			this->txtVal2->Size = System::Drawing::Size(100, 20);
			this->txtVal2->TabIndex = 29;
			// 
			// txtVal1
			// 
			this->txtVal1->Location = System::Drawing::Point(98, 177);
			this->txtVal1->Name = L"txtVal1";
			this->txtVal1->Size = System::Drawing::Size(100, 20);
			this->txtVal1->TabIndex = 28;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(276, 180);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(31, 13);
			this->label6->TabIndex = 27;
			this->label6->Text = L"Valor";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(31, 184);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(31, 13);
			this->label5->TabIndex = 26;
			this->label5->Text = L"Valor";
			// 
			// btbTam2
			// 
			this->btbTam2->Location = System::Drawing::Point(279, 126);
			this->btbTam2->Name = L"btbTam2";
			this->btbTam2->Size = System::Drawing::Size(75, 23);
			this->btbTam2->TabIndex = 25;
			this->btbTam2->Text = L"Definir";
			this->btbTam2->UseVisualStyleBackColor = true;
			this->btbTam2->Click += gcnew System::EventHandler(this, &Form1::btbTam2_Click);
			// 
			// txtTam2
			// 
			this->txtTam2->Location = System::Drawing::Point(328, 77);
			this->txtTam2->Name = L"txtTam2";
			this->txtTam2->Size = System::Drawing::Size(100, 20);
			this->txtTam2->TabIndex = 24;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(276, 83);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(46, 13);
			this->label4->TabIndex = 23;
			this->label4->Text = L"Tamano";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(276, 26);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(14, 13);
			this->label3->TabIndex = 22;
			this->label3->Text = L"B";
			// 
			// btbTam1
			// 
			this->btbTam1->Location = System::Drawing::Point(34, 126);
			this->btbTam1->Name = L"btbTam1";
			this->btbTam1->Size = System::Drawing::Size(75, 23);
			this->btbTam1->TabIndex = 21;
			this->btbTam1->Text = L"Definir";
			this->btbTam1->UseVisualStyleBackColor = true;
			this->btbTam1->Click += gcnew System::EventHandler(this, &Form1::btbTam1_Click);
			// 
			// txtTam1
			// 
			this->txtTam1->Location = System::Drawing::Point(98, 80);
			this->txtTam1->Name = L"txtTam1";
			this->txtTam1->Size = System::Drawing::Size(100, 20);
			this->txtTam1->TabIndex = 20;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(31, 80);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(46, 13);
			this->label2->TabIndex = 19;
			this->label2->Text = L"Tamano";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(31, 26);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(14, 13);
			this->label1->TabIndex = 18;
			this->label1->Text = L"A";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(666, 484);
			this->Controls->Add(this->grilla3);
			this->Controls->Add(this->btbConcatenar);
			this->Controls->Add(this->grilla2);
			this->Controls->Add(this->grilla1);
			this->Controls->Add(this->btbVal2);
			this->Controls->Add(this->btbVal1);
			this->Controls->Add(this->txtVal2);
			this->Controls->Add(this->txtVal1);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->btbTam2);
			this->Controls->Add(this->txtTam2);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->btbTam1);
			this->Controls->Add(this->txtTam1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btbTam1_Click(System::Object^  sender, System::EventArgs^  e) {
			int T1;
				 T1=System::Convert::ToInt32(txtTam1->Text);
				 vec1.set_tamano(T1);
				 grilla1->RowCount=vec1.get_tamano();
				 
				 pos=0; }
private: System::Void btbVal1_Click(System::Object^  sender, System::EventArgs^  e) {
		 	double elem1;
			 elem1=System::Convert::ToDouble(txtVal1->Text);
			
			 if(vec1.Insertar(pos,elem1))
			 {	 vec1.set_vector(pos,elem1);
				 pos++;
				 grilla1->ColumnCount=1;
				 grilla1->ColumnCount=vec1.get_tamano();
				 double val1;
				 for(int i=0;i<vec1.get_tamano();i++)
				 {
					 val1=vec1.get_vector(i);
				     grilla1->Rows[i]->Cells[0]->Value=System::Convert::ToDouble(val1);
					 
					 
				 }
			 }
		 }
private: System::Void btbTam2_Click(System::Object^  sender, System::EventArgs^  e) {
		 int T1;
				 T1=System::Convert::ToInt32(txtTam2->Text);
				 vec2.set_tamano(T1);
				 grilla2->RowCount=vec2.get_tamano();
				 
				 pos=0;}

private: System::Void btbVal2_Click(System::Object^  sender, System::EventArgs^  e) {
		 double elem2;
			 elem2=System::Convert::ToDouble(txtVal2->Text);
			 if(vec2.Insertar(pos,elem2))
			 { 
              vec2.set_vector(pos,elem2);
			 	 pos++;
				 grilla2->ColumnCount=1;
				 grilla2->ColumnCount=vec2.get_tamano();
				 double val2;
				 for(int i=0;i<vec2.get_tamano();i++)
				 {
					 val2=vec2.get_vector(i);
					 grilla2->Rows[i]->Cells[0]->Value=System::Convert::ToDouble(val2);
					 }
			 }
		 }
private: System::Void btbConcatenar_Click(System::Object^  sender, System::EventArgs^  e) {
		 int T1,T2,T3;
			T1=System::Convert::ToInt32(txtTam1->Text);
			T2=System::Convert::ToInt32(txtTam2->Text);
			T3=T1+T2;
			vec3.set_tamano(T3);
			grilla3->RowCount=vec3.get_tamano();
			  for(int i=0;i<vec1.get_tamano();i++)
			 {
				vec3.set_vector(i,vec1.get_vector(i));
			 }
				for(int k=vec1.get_tamano();k<(vec1.get_tamano()+vec2.get_tamano());k++)
				{vec3.set_vector(k,vec2.get_vector(k-vec1.get_tamano()));
				}

			for(int i=0;i<vec3.get_tamano();i++)
			{
				grilla3->Rows[i]->Cells[0]->Value=System::Convert::ToDouble(vec3.get_vector(i));
			} }
};
}

