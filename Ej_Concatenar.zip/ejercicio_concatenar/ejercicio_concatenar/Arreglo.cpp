#include "StdAfx.h"
#include "Arreglo.h"


Arreglo::Arreglo(void)
{
}
int Arreglo::get_tamano()
{
	return tamano;
}
void Arreglo::set_tamano(int tam)
{
	tamano=tam;
}
double Arreglo::get_vector(int posicion)
{
	return vec[posicion];
}
void Arreglo::set_vector(int posicion, double elemento)
{
	vec[posicion]=elemento;
}
bool Arreglo::LlenoVector()
{
	if(tamano==Mmax-1)
	{return true;}
	else{return false;}
}
bool Arreglo::VacioVector()
{
	if(tamano==0)
	{return true;}
	else{return false;}
}
bool Arreglo::Insertar(int posicion, double elemento)
{
	if((posicion<0)&&(posicion>tamano))
	{return false;}
	else
		{
			if(LlenoVector()==true)
			{return false;}
			else
				{
					int i=get_tamano();
					while(i>posicion)
					{
						vec[i]=vec[i-1];
						i--;
					}
					vec[i]=elemento;
					return true;
				}

		}
}
