#pragma once
#define Nmax 100
#define Mmax 100
class Arreglo
{
private:
	double vec[Nmax];
	int tamano;
public:
	Arreglo(void);
	double get_vector(int posicion);
	void set_vector(int posicion, double elemento);
	int get_tamano();
	void set_tamano(int tam);
	bool LlenoVector();
	bool VacioVector();
	bool Insertar(int posicion ,double elemento);

};

