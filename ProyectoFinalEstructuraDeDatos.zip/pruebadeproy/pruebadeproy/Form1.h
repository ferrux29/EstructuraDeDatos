#pragma once
#include "Mat.h"

namespace pruebadeproy {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	Mat mat1;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  dataGridView1;
	protected: 
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::Button^  button6;
	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  button1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->BeginInit();
			this->SuspendLayout();
			// 
			// dataGridView1
			// 
			this->dataGridView1->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::AllCells;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(2) {this->Column1, 
				this->Column2});
			this->dataGridView1->Location = System::Drawing::Point(379, 118);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->RowHeadersVisible = false;
			this->dataGridView1->Size = System::Drawing::Size(199, 218);
			this->dataGridView1->TabIndex = 14;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Producto";
			this->Column1->Name = L"Column1";
			this->Column1->Width = 75;
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Cantidad";
			this->Column2->Name = L"Column2";
			this->Column2->Width = 74;
			// 
			// button6
			// 
			this->button6->BackColor = System::Drawing::SystemColors::ButtonFace;
			this->button6->Font = (gcnew System::Drawing::Font(L"Segoe Print", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button6->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"button6.Image")));
			this->button6->ImageAlign = System::Drawing::ContentAlignment::MiddleLeft;
			this->button6->Location = System::Drawing::Point(379, 345);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(199, 41);
			this->button6->TabIndex = 13;
			this->button6->UseVisualStyleBackColor = false;
			this->button6->Click += gcnew System::EventHandler(this, &Form1::button6_Click);
			// 
			// button4
			// 
			this->button4->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"button4.Image")));
			this->button4->Location = System::Drawing::Point(203, 266);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(170, 120);
			this->button4->TabIndex = 12;
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Form1::button4_Click);
			// 
			// button3
			// 
			this->button3->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"button3.Image")));
			this->button3->Location = System::Drawing::Point(12, 266);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(170, 120);
			this->button3->TabIndex = 11;
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// button2
			// 
			this->button2->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"button2.Image")));
			this->button2->Location = System::Drawing::Point(203, 118);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(170, 120);
			this->button2->TabIndex = 10;
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// button1
			// 
			this->button1->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"button1.Image")));
			this->button1->Location = System::Drawing::Point(12, 118);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(170, 120);
			this->button1->TabIndex = 9;
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(598, 432);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->button6);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedToolWindow;
			this->Name = L"AutoMed";
			this->Text = L"AutoMed";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			 int cont;
			     cont=System::Convert::ToInt32(dataGridView1->Rows[0]->Cells[1]->Value);
			     cont++;
			     mat1.Set_Matriz(0,1,cont);
			     dataGridView1->Rows[0]->Cells[1]->Value=mat1.Get_Matriz(0,1);
			 }
private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 dataGridView1->RowCount=4;			 
			 dataGridView1->Rows[0]->Cells[0]->Value="Alcohol en Gel (15bs)";
			 dataGridView1->Rows[0]->Cells[1]->Value=0;
			 dataGridView1->Rows[1]->Cells[0]->Value="Test de Covid (25bs)";
			 dataGridView1->Rows[1]->Cells[1]->Value=0;
			 dataGridView1->Rows[2]->Cells[0]->Value="Barbijo (5bs)";
			 dataGridView1->Rows[2]->Cells[1]->Value=0;
			 dataGridView1->Rows[3]->Cells[0]->Value="Guantes (10bs)";
			 dataGridView1->Rows[3]->Cells[1]->Value=0;
		 }
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
         int cont;
			     cont=System::Convert::ToInt32(dataGridView1->Rows[1]->Cells[1]->Value);
			     cont++;
			     mat1.Set_Matriz(1,1,cont);
			     dataGridView1->Rows[1]->Cells[1]->Value=mat1.Get_Matriz(1,1);
		 }
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
		 int cont;
			     cont=System::Convert::ToInt32(dataGridView1->Rows[2]->Cells[1]->Value);
			     cont++;
			     mat1.Set_Matriz(2,1,cont);
			     dataGridView1->Rows[2]->Cells[1]->Value=mat1.Get_Matriz(2,1);
		 }
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {
		 int cont;
			     cont=System::Convert::ToInt32(dataGridView1->Rows[3]->Cells[1]->Value);
			     cont++;
			     mat1.Set_Matriz(3,1,cont);
			     dataGridView1->Rows[3]->Cells[1]->Value=mat1.Get_Matriz(3,1);
		 }
private: System::Void button6_Click(System::Object^  sender, System::EventArgs^  e) {
         int precioT=0;
			 precioT+=Convert::ToInt32(dataGridView1->Rows[0]->Cells[1]->Value)*15;
			 precioT+=Convert::ToInt32(dataGridView1->Rows[1]->Cells[1]->Value)*25;
			 precioT+=Convert::ToInt32(dataGridView1->Rows[2]->Cells[1]->Value)*5;
			 precioT+=Convert::ToInt32(dataGridView1->Rows[3]->Cells[1]->Value)*10;
			 MessageBox::Show("Precio Total a Pagar "+precioT +"bs","Realizar Pago");

		 }
};
}

