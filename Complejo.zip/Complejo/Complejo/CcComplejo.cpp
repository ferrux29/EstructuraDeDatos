#include "StdAfx.h"
#include "CcComplejo.h"


CcComplejo::CcComplejo(void)
{
}
    void CcComplejo::Set_real(double r)
    {real=r;}
	void CcComplejo::Set_imag(double i)
	{imag=i;}
	double CcComplejo::Get_real() const
	{return real;}
	double CcComplejo::Get_imag() const
	{return imag;}
	void CcComplejo::suma(const CcComplejo a, const CcComplejo b)
	{real=a.real+b.real;
	 imag=a.imag+b.imag;}