#pragma once
class CcComplejo
{private:
    double real;
	double imag;

public:
	CcComplejo(void);
	CcComplejo(double r, double i);
	void Set_real(double r);
	void Set_imag(double i);
	double Get_real() const;
	double Get_imag() const;
	void suma(const CcComplejo a, const CcComplejo b);
};

