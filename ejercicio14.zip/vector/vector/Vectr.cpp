#include "StdAfx.h"
#include "Vectr.h"
#include <iostream>
#include <iomanip>
#define Nmax 100
using namespace std;

Vectr::Vectr(void)
{vec[Nmax]=0;
tama�o=0;
}
Vectr::~Vectr(void)
{}
double Vectr::Get_tama�o()
{return tama�o;}
void Vectr::Set_tama�o(int t)
{tama�o=t;}
double Vectr::Get_vector(int posici�n)
{return vec[posici�n]; }
void Vectr::Set_vector(int posici�n, float _elemento)
{vec[posici�n]=_elemento;}
void Vectr::Incrementar()
{tama�o++;}
void Vectr::Reducir()
{tama�o--;}
bool Vectr::Vector_vacio()
{if (tama�o==0){return true;}
else{return false;}
}
bool Vectr::Vector_lleno()
{if (tama�o==(Nmax-1)){return true;}
else{return false;}
}
bool Vectr::Insertar(float _elemento, int posici�n)
{if((posici�n<0)&&(posici�n>tama�o))
{return false;}
else{if(Vector_lleno()==true){return false;}
else{int i=Get_tama�o();
while(i>posici�n){vec[i]=vec[i-1];
i--;}
vec[posici�n]=_elemento; return true;}
 }
}

void Vectr::ordenarVector(){
float aux; int i,j;
    for(i=1; i<tama�o; i++)
	{
		for(j=0; j<tama�o-i; j++)
		{
			if(vec[j]>vec[j+1])
			{
			    aux    = vec[j+1];
				vec[j+1] = vec[j];
				vec[j]   = aux;}
		}
	}
}
