#pragma once
#define Nmax 100
class Vectr
{
private:
	double vec[Nmax];
	double tama�o;
public:
	Vectr(void);
	~Vectr(void);
	double Get_tama�o();
	void Set_tama�o(int t);

	double Get_vector(int posici�n);
	void Set_vector(int posici�n,float _elemento);
	void Incrementar();
	void Reducir();
	bool Vector_vacio();
	bool Vector_lleno();
	bool Insertar(float _elemento, int posici�n);
	void ordenarVector();
};

