#include "StdAfx.h"
#include "Cuenta.h"


Cuenta::Cuenta(void)
{
}
void Cuenta::Set_Nombre(string nom){
Nombre=nom;}
void Cuenta::Set_Cuenta(string cue){
Cuenta=cue;}
void Cuenta::Set_TipoDeInteres(double tipo){
TipoDeInteres=tipo;}
string Cuenta::Get_Nombre(){
return Nombre;}
string Cuenta::Get_Cuenta(){
return Cuenta;}
double Cuenta::Get_TipoDeInteres(){
return TipoDeInteres;}
double Cuenta::estado(){
return saldo;}
void Cuenta::reintegro(double cantidad){
saldo=saldo-cantidad;}
void Cuenta::ingreso(double cantidad){
saldo=saldo-cantidad;}
