#pragma once
#include "Cuenta.h"
#include <iostram>
#include <string>
using namespace std;
class CuentaAhorro:public Cuenta
{
private:
	double CuotaMantenimiento;
public:
	CuentaAhorro(void);
	void Set_CuotaMantenimiento(double cantidad);
	double Get_CuotaMantenimiento();
	void reintegro(double cantidad);
};

