#include "StdAfx.h"
#include "CuentaAhorro.h"


CuentaAhorro::CuentaAhorro(void)
{
}
void CuentaAhorro::Set_CuotaMantenimiento(double cantidad){
CuentaMantenimiento=cantidad;}
double CuentaAhorro::Get_CuotaMantenimiento(){
return CuotaMantenimiento;}
void CuentaAhorro::reintegro(double cantidad){
saldo=saldo-cantidad;}