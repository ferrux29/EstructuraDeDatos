#pragma once
#include <iostream>
#include <string.h>
class Cuenta
{
private:
	double saldo;
	string cuenta;
	string nombre;


public:
	Cuenta(void);

void Set_Nombre(string nom);
void Set_Cuenta(string cue);
void Set_TipoDeInteres(double tipo);
string Get_Nombre();
string Get_Cuenta();
double Get_TipoDeInteres();
double estado();
void reintegro(double cantidad);
void ingreso(double cantidad);
};

