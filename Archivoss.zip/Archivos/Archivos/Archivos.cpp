// Archivos.cpp : main project file.

#include "stdafx.h"

#include "StdAfx.h"
#include <iostream>
#include <fstream>
#include <conio.h>
#include "ABMamigo.cpp"

using namespace std;


void menu(){
cout<<"MENU"<<endl;
cout<<"1.-Adicionar"<<endl;
cout<<"2.-Buscar"<<endl;
cout<<"3.-Eliminar"<<endl;
cout<<"4.-Modificar"<<endl;
cout<<"5.-Salir"<<endl;}
void main() {
	menu();int opc=0;
	while(true){
	cout<<"Digite la opcion"<<endl;
	cin>>opc;
	ABMamigo *amig = new ABMamigo("amigOO.dat");
	switch(opc){
    
    case 1:amig->adicionarNuevo();
	       amig->listar();break;
    case 2:amig->buscarReg();break;
	case 3:amig->eliminarReg();break;
	case 4:amig->modificarReg();
	       amig->listar();break;
	       //getch();;
	default:cout<<"Digite una opcion valida"<<endl;
	}
 }
}
