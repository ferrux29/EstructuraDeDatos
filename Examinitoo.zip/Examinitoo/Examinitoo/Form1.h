#pragma once
#include <iostream>
#include <string>
#include "arreglo.h"
#include <msclr\marshal_cppstd.h>
namespace Examinitoo {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;
	arreglo arreglo_arreglito;
		float pos=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 

	protected: 

	private: System::Windows::Forms::DataGridView^  grilla_valores;
	protected: 

	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::TextBox^  txtTam;

	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button2;




	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->grilla_valores = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->txtTam = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_valores))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(12, 46);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(49, 13);
			this->label1->TabIndex = 2;
			this->label1->Text = L"Cantidad";
			// 
			// grilla_valores
			// 
			this->grilla_valores->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla_valores->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grilla_valores->Location = System::Drawing::Point(15, 146);
			this->grilla_valores->Name = L"grilla_valores";
			this->grilla_valores->Size = System::Drawing::Size(204, 118);
			this->grilla_valores->TabIndex = 6;
			this->grilla_valores->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Form1::grilla_valores_CellContentClick);
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Elementos";
			this->Column1->Name = L"Column1";
			// 
			// txtTam
			// 
			this->txtTam->Location = System::Drawing::Point(76, 43);
			this->txtTam->Name = L"txtTam";
			this->txtTam->Size = System::Drawing::Size(71, 20);
			this->txtTam->TabIndex = 5;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(169, 31);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(95, 35);
			this->button1->TabIndex = 4;
			this->button1->Text = L"Definir";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(234, 146);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(89, 42);
			this->button2->TabIndex = 7;
			this->button2->Text = L"Generar";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(335, 319);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->grilla_valores);
			this->Controls->Add(this->txtTam);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_valores))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			 int tam;
			 tam=System::Convert::ToInt32(txtTam->Text);
			 arreglo_arreglito.set_tamano(tam);
			 grilla_valores->RowCount=arreglo_arreglito.get_tamano();
			 pos=0;}

private: System::Void grilla_valores_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
		 }
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
			 arreglo_arreglito.multiplos();
			 for(int i=0;i<arreglo_arreglito.get_tamano();i++){
			 grilla_valores->Rows[i]->Cells[0]->Value=arreglo_arreglito.get_vector(i);}
		 }
};
}

