#include "StdAfx.h"
#include "arreglo.h"
#include <iostream>
#define Nmax 100

arreglo::arreglo(void)
{
	vec[Nmax]=0;
	   tamano=0;
}
arreglo::~arreglo(void)
{
}
int arreglo::get_tamano()
{return tamano;}
void arreglo::set_tamano(int t)
{tamano=t;}
int arreglo::get_vector(int posicion)
{return vec[posicion];}
void arreglo::set_vector(int posicion, int _elemento)
{vec[posicion]=_elemento;}
void arreglo::Incrementar()
	{tamano++;}
void arreglo::Reducir()
{tamano--;}
bool arreglo::Vector_vacio()
{if (tamano==0){return true;}
else{return false;}
}
bool arreglo::Vector_lleno()
{if (tamano==(Nmax-1)){return true;}
else{return false;}
}
bool arreglo::Insertar(int _elemento, int posicion)
{if((posicion<0)&&(posicion>tamano))
{return false;}
else{if(Vector_lleno()==true){return false;}
else{int i=get_tamano();
while(i>posicion){vec[i]=vec[i-1];
i--;}
vec[posicion]=_elemento; return true;}
 }
}
void arreglo::multiplos()
{int N,x,y,z;
x=0;
for(int i=0;i<=tamano;i++){
 N=x+3;
 vec[i]=N;
 x=N;}
}