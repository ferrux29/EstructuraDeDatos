#pragma once
#define Nmax 100
class arreglo
{
private:
	int vec[Nmax];
	int tamano;
public:
	arreglo(void);
	~arreglo(void);
	int get_tamano();
	void set_tamano(int t);
	int get_vector(int posicion);
	void set_vector(int posicion, int _elemento);
	void Incrementar();
	void Reducir();
	bool Vector_vacio();
	bool Vector_lleno();
	bool Insertar(int _elemento, int posicion);
	void multiplos();
};

